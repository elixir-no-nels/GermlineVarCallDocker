rm Rakefile
rm workflow_test_task_*.rb
rm workflow_test_default*.rb
rm -rf Logs
rm -rf lib
rm -rf StepStatus
rm -rf Result_0*
rm -rf step_status
