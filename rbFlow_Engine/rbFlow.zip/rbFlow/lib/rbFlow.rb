# require 'awesome_print' if @debug
require 'rake'
require 'version.rb'
require 'workflow.rb'

#  Load all others used classes
module RbFlow

end
