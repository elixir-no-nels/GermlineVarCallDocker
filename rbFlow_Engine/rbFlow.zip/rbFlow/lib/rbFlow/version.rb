module RbFlow
  VERSION = 'dev version 0.9.0'
end
